#!/usr/bin/env node
/**
 * VPS Monitor Pro+ v2.0 - Official Node Agent (Daemon)
 * Fully compatible with app.js v2.0+ Ultimate Edition
 * Enhanced: swap, container awareness, better reconnect, structured logs
 * Made with ❤️ by Hopingboyz • 2026
 */

require('dotenv').config();
const os = require('os');
const fs = require('fs');
const path = require('path');
const si = require('systeminformation');
const axios = require('axios');
const { setTimeout: sleep } = require('timers/promises');

// ────────────────────────────────────────────────
// CONFIGURATION + VALIDATION
// ────────────────────────────────────────────────
const requiredEnv = ['SERVER_URL', 'API_KEY'];
requiredEnv.forEach(key => {
    if (!process.env[key]?.trim()) {
        console.error(`\x1b[31mERROR: Missing required env: ${key}\x1b[0m`);
        process.exit(1);
    }
});

const API_KEY = process.env.API_KEY.trim();
if (API_KEY.length !== 64 || !/^[a-f0-9]{64}$/i.test(API_KEY)) {
    console.error('\x1b[31mERROR: API_KEY must be 64 hex characters\x1b[0m');
    process.exit(1);
}

const CONFIG = {
    SERVER_URL: process.env.SERVER_URL.replace(/\/+$/, ''),
    API_KEY,
    NODE_NAME: (process.env.NODE_NAME || os.hostname()).trim(),
    GROUP_TAGS: (process.env.GROUP_TAGS || '').trim(), // comma separated, optional
    REPORT_INTERVAL_MS: Math.max(5000, parseInt(process.env.REPORT_INTERVAL || '10000', 10)),
    LATENCY_TEST: process.env.LATENCY_TEST !== 'false',
    LOG_JSON: process.env.LOG_JSON === 'true',
    DEBUG: process.env.DEBUG === 'true',
    MAX_RECONNECT_ATTEMPTS: 25,
    RECONNECT_BASE_MS: 3000,
    AGENT_VERSION: '7.0'
};

const log = (msg, level = 'info') => {
    const ts = new Date().toISOString();
    if (CONFIG.LOG_JSON) {
        console.log(JSON.stringify({ ts, level, message: msg }));
    } else {
        const color = level === 'error' ? '\x1b[31m' : level === 'warn' ? '\x1b[33m' : '';
        console.log(`${color}[${ts}] ${msg}\x1b[0m`);
    }
};

const debug = (msg) => CONFIG.DEBUG && log(`[DEBUG] ${msg}`, 'debug');

// Single instance lock
const LOCK_FILE = path.join(os.tmpdir(), 'vps-monitor-agent.lock');
if (fs.existsSync(LOCK_FILE)) {
    try {
        const pid = Number(fs.readFileSync(LOCK_FILE, 'utf8'));
        if (process.kill(pid, 0)) {
            log('Another agent instance is running. Exiting.', 'error');
            process.exit(1);
        }
    } catch { /* stale lock */ }
}
fs.writeFileSync(LOCK_FILE, process.pid.toString());
process.on('exit', () => {
    try { fs.unlinkSync(LOCK_FILE); } catch {}
});

// ────────────────────────────────────────────────
// STATE
// ────────────────────────────────────────────────
let isRegistered = false;
let reconnectAttempts = 0;
let previousNetStats = null; // for calculating delta rx/tx

// ────────────────────────────────────────────────
// UTILITIES
// ────────────────────────────────────────────────
async function measureLatency() {
    if (!CONFIG.LATENCY_TEST) return 0;
    const start = Date.now();
    try {
        await axios.head(CONFIG.SERVER_URL, { timeout: 4000 });
        return Date.now() - start;
    } catch {
        return 9999;
    }
}

function getJitterDelay(attempt) {
    const base = CONFIG.RECONNECT_BASE_MS * Math.pow(1.6, attempt);
    const jitter = Math.random() * 0.3 * base; // ±30%
    return Math.min(base + jitter, 60000); // cap at 60s
}

// ────────────────────────────────────────────────
// REGISTRATION
// ────────────────────────────────────────────────
async function registerNode() {
    try {
        const payload = {
            api_key: CONFIG.API_KEY,
            name: CONFIG.NODE_NAME,
            hostname: os.hostname(),
            agent_version: CONFIG.AGENT_VERSION,
            ...(CONFIG.GROUP_TAGS && { group_tags: CONFIG.GROUP_TAGS })
        };

        const { data } = await axios.post(
            `${CONFIG.SERVER_URL}/api/node/register`,
            payload,
            { timeout: 10000 }
        );

        if (data.success) {
            log(`Registered → Node ID: ${data.node_id || 'unknown'}`);
            isRegistered = true;
            reconnectAttempts = 0;
            return true;
        }
        log(`Registration rejected: ${data.error || 'no message'}`, 'warn');
    } catch (err) {
        log(`Register failed: ${err.response?.data?.error || err.message}`, 'error');
    }
    return false;
}

// ────────────────────────────────────────────────
// COLLECT METRICS (enhanced)
// ────────────────────────────────────────────────
async function collectStats() {
    try {
        const promises = [
            si.currentLoad(),
            si.cpu(),
            si.mem(),
            si.fsSize(),
            si.networkStats(),
            si.networkInterfaces(),
            si.osInfo(),
            si.processes(),
            si.cpuTemperature().catch(() => ({ main: null })),
            si.memLayout().catch(() => null),   // extra ram info
            si.services('*').catch(() => null)  // optional: running services count
        ];

        const [
            load, cpu, mem, fsSize, netStatsRaw,
            netIfaces, osInfo, processes, temp,
            memLayout, services
        ] = await Promise.all(promises);

        // ── Network ──────────────────────────────────────
        const defaultIface = netIfaces.find(i => i.default) || netIfaces[0] || {};
        const ifaceName = defaultIface.iface || 'unknown';
        const currentNet = netStatsRaw.find(s => s.iface === ifaceName) || {};

        let rx_sec = 0, tx_sec = 0;
        if (previousNetStats && previousNetStats.iface === ifaceName) {
            const timeDiff = (currentNet.ms || Date.now()) - (previousNetStats.ms || 0);
            if (timeDiff > 0) {
                rx_sec = ((currentNet.rx_bytes || 0) - (previousNetStats.rx_bytes || 0)) / (timeDiff / 1000);
                tx_sec = ((currentNet.tx_bytes || 0) - (previousNetStats.tx_bytes || 0)) / (timeDiff / 1000);
            }
        }
        previousNetStats = { ...currentNet, iface: ifaceName, ms: Date.now() };

        // ── Disk (prefer / or largest) ───────────────────
        const rootDisk = fsSize.find(d => d.mount === '/' || d.mount === 'C:\\') ||
                        fsSize.sort((a,b) => b.size - a.size)[0] || {};

        // ── CPU Temp ─────────────────────────────────────
        const cpuTemp = temp?.main ?? temp?.cores?.[0] ?? null;

        // ── Container / cgroup awareness ─────────────────
        const inContainer = fs.existsSync('/.dockerenv') || fs.existsSync('/proc/1/cgroup') && fs.readFileSync('/proc/1/cgroup', 'utf8').includes('docker');

        return {
            cpu: Math.round(load.currentLoad || 0),
            cpu_cores: cpu.cores || os.cpus().length,
            memory: {
                total: mem.total,
                used: mem.used,
                free: mem.free,
                usedPercent: mem.total ? Number((mem.used / mem.total * 100).toFixed(1)) : 0
            },
            swap: {
                total: mem.swaptotal,
                used: mem.swapused,
                free: mem.swapfree,
                usedPercent: mem.swaptotal ? Number((mem.swapused / mem.swaptotal * 100).toFixed(1)) : 0
            },
            disk: {
                total: rootDisk.size || 0,
                used: rootDisk.used || 0,
                free: rootDisk.available || 0,
                usedPercent: rootDisk.size ? Number((rootDisk.used / rootDisk.size * 100).toFixed(1)) : 0
            },
            network: {
                interface: ifaceName,
                rx_sec: Math.round(rx_sec),
                tx_sec: Math.round(tx_sec)
            },
            uptime: Math.round(os.uptime()),
            loadavg: os.loadavg().map(v => Math.round(v * 100) / 100),
            cpu_temp: cpuTemp,
            processes: {
                all: processes.all || 0,
                running: processes.running || 0
            },
            os_version: `${osInfo.distro} ${osInfo.release} (${osInfo.arch})`.trim(),
            containerized: !!inContainer,
            // optional extra fields
            ...(memLayout && { ram_modules: memLayout.length }),
            ...(services && { services_running: services.length })
        };
    } catch (err) {
        log(`Stats collection failed: ${err.message}`, 'error');
        return null;
    }
}

// ────────────────────────────────────────────────
// SEND REPORT
// ────────────────────────────────────────────────
async function report() {
    if (!isRegistered) {
        if (!(await registerNode())) {
            reconnectLater();
            return;
        }
    }

    const stats = await collectStats();
    if (!stats) return;

    const latency = await measureLatency();

    try {
        await axios.post(
            `${CONFIG.SERVER_URL}/api/node/report`,
            {
                api_key: CONFIG.API_KEY,
                latency,
                stats
            },
            { timeout: 12000 }
        );

        debug(`Report OK | CPU ${stats.cpu}% | RAM ${stats.memory.usedPercent}% | SWAP ${stats.swap.usedPercent}% | Net ${stats.network.rx_sec}/${stats.network.tx_sec} B/s`);
        reconnectAttempts = 0;
    } catch (err) {
        log(`Report failed → ${err.response?.data?.error || err.message}`, 'error');
        isRegistered = false;
        reconnectLater();
    }
}

function reconnectLater() {
    if (reconnectAttempts >= CONFIG.MAX_RECONNECT_ATTEMPTS) {
        log('Max reconnect attempts reached. Exiting.', 'error');
        process.exit(1);
    }

    const delay = getJitterDelay(reconnectAttempts);
    reconnectAttempts++;
    log(`Reconnect attempt ${reconnectAttempts}/${CONFIG.MAX_RECONNECT_ATTEMPTS} in ~${Math.round(delay/1000)}s`);
    setTimeout(report, delay);
}

// ────────────────────────────────────────────────
// SHUTDOWN
// ────────────────────────────────────────────────
const shutdown = (sig) => {
    log(`Received ${sig}. Shutting down...`);
    try { fs.unlinkSync(LOCK_FILE); } catch {}
    process.exit(0);
};

['SIGINT', 'SIGTERM', 'SIGHUP'].forEach(sig => process.on(sig, () => shutdown(sig)));

// ────────────────────────────────────────────────
// START
// ────────────────────────────────────────────────
(async function startAgent() {
    log('╔════════════════════════════════════════════════════╗');
    log('║  VPS Monitor Pro+ Agent v7.0  •  Ultimate Edition  ║');
    log('║  Real-time • Swap • Container-aware • Resilient    ║');
    log(`║  Server → ${CONFIG.SERVER_URL}`);
    log(`║  Node  → ${CONFIG.NODE_NAME}${CONFIG.GROUP_TAGS ? ` (${CONFIG.GROUP_TAGS})` : ''}`);
    log(`║  Interval → ${CONFIG.REPORT_INTERVAL_MS / 1000}s`);
    log('╚════════════════════════════════════════════════════╝');

    // First report immediately
    await report();

    // Then periodic
    setInterval(report, CONFIG.REPORT_INTERVAL_MS);
})();